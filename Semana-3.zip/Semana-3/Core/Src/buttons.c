/* ***************************************************************** */
/* File name:        buttons.c                                       */
/* File description: Corpo das funções em buttons.c                  */
/*                                                                   */
/* Author name:      Henrique M Bianchi                              */
/*                   Guilherme S Brumatti                            */
/* Creation date:    23mar2023                                       */
/* Revision date:                                                    */
/* ***************************************************************** */

/* our includes */
#include "main.h"
#include "buttons.h"

/* ************************************************ */
/* Method name: 	   buttonsInitButtons      		*/
/* Method description: Inicializa funções dos leds  */
/* Input params:	   Botao   (1 a 5)              */
/* Output params:	   n/a 							*/
/* ************************************************ */
void buttonsInitButtons(){

	//Libera Clock para Porta B e C
	RCC->AHB2ENR |= 0x6;

	//Define a Porta PC1 como GPIO
	GPIOC->MODER &= ~0x8;
	GPIOC->MODER &= ~0x4;
	//Define PC1 como GPIO_Push-Pull (Botão (Cima))
	GPIOC->OTYPER &= ~0x2;

	//Define a Porta PC2 como GPIO
	GPIOC->MODER &= ~0x20;
	GPIOC->MODER &= ~0x10;
	//Define PC2 como GPIO_Push-Pull (Botão (Baixo))
	GPIOC->OTYPER &= ~0x4;

	//Define a Porta PC3 como GPIO
	GPIOC->MODER &= ~0x80;
	GPIOC->MODER &= ~0x40;
	//Define PC2 como GPIO_Push-Pull (Botão (Esquerda))
	GPIOC->OTYPER &= ~0x8;

	//Define a Porta PC4 como GPIO
	GPIOC->MODER &= ~0x200;
	GPIOC->MODER &= ~0x100;
	//Define PC4 como GPIO_Push-Pull (Botão (Direita))
	GPIOC->OTYPER &= ~0x10;

	//Define a Porta PB0 como GPIO
	GPIOB->MODER &= ~0x1;
	GPIOB->MODER &= ~0x2;
	//Define PB0 como GPIO_Push-Pull (Botão (Enter))
	GPIOB->OTYPER &= ~0x1;
}

/* ************************************************ */
/* Method name: 	   statusButton        	*/
/* Method description: Mostra o status do botão     */
/* Input params:	   Inteiro (1 a 5)              */
/* Output params:	   1 = botão pressionado 		*/
/*					   0 = botão solto              */
/* ************************************************ */
int statusButton(int ibutton_x){
	//Botão (Cima)
	if(ibutton_x == 1){
		return (GPIOC->IDR & 0x2);
	}
	//Botão (Baixo)
	else if(ibutton_x == 2){
		return (GPIOC->IDR & 0x4);
	}
	//Botão (Esquerda)
	else if(ibutton_x == 3){
		return (GPIOC->IDR & 0x8);
	}
	//Botão (Direita)
	else if(ibutton_x == 4){
		return (GPIOC->IDR & 0x10);
    }
	//Botão (Enter)
	else if(ibutton_x == 5){
		return (GPIOB->IDR & 0x1);
	}
}
