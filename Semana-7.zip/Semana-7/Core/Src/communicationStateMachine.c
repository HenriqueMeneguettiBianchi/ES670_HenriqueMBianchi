/* ***************************************************************** */
/* File name:        communicationStateMachine.c                     */
/* File description: Funções de communicationStateMachine.c          */
/*                                                                   */
/* Author name:      Henrique M Bianchi                              */
/*                   Lucas Martins Cardozo                           */
/* Creation date:    25mai2023                                       */
/* Revision date:                                                    */
/* ***************************************************************** */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "usart.h"
#include "led.h"
#include "buttons.h"
#include "buttonsEvents.h"
#include "communicationStateMachine.h"

#define IDDLE '0'
#define READY '1'
#define GET   '3'
#define SET   '4'
#define PARAM '5'
#define VALUE '6'

#define NUM_MAX_VALUE 7

unsigned char ucUartState = IDDLE;
unsigned char ucValueCount;

unsigned char ucAux;
unsigned char ucButton;


void initUart(){
		HAL_UART_Receive_IT(&hlpuart1, &ucAux, 1);
}

void HAL_UART_RxCpltCallback (UART_HandleTypeDef *huart){
	if(huart == &hlpuart1){
		maquinaEstadoByteCommunication(ucAux);
		HAL_UART_Transmit_IT(&hlpuart1, &ucAux, 1);
		HAL_UART_Receive_IT(&hlpuart1, &ucAux, 1);
	}
}

void maquinaEstadoByteCommunication(unsigned char ucByte){

	static unsigned char ucParam;
	static unsigned char ucValue[NUM_MAX_VALUE];

	if (ucByte == '#'){
		ucUartState = READY;

	}
	else{

		if(IDDLE != ucUartState){

			if(ucUartState == READY){
				if(ucByte == 'g'){
					ucUartState = GET;
				}
				else if(ucByte == 's'){
					ucUartState = SET;
				}
				else{
					ucUartState = IDDLE;
				}
			}

			else if(ucUartState == GET){
				//f = obtém duty-cicle do cooler
				//a = obtém temperatura atual
				if(ucByte == 'f' || ucByte == 'a'){
					ucUartState = PARAM;
					ucParam = ucByte;
				}
				else{
					ucUartState = IDDLE;
				}

			}
			else if(ucUartState == SET){
				//t = define temperatura
				//b = habilita/desabilita botão
				//c = controla cooler
				//q = controla aquecedor
				if(ucByte == 't' || ucByte == 'b' || ucByte == 'c' || ucByte == 'q'){
					ucUartState = VALUE;
					ucParam = ucByte;
					ucValueCount = 0;
				}
				else{
					ucUartState = IDDLE;
				}
			}

			else if(ucUartState == PARAM){
				if(ucByte == ';'){
					if(ucParam == 'a'){
						//HAL_UART_Transmit_IT(&hlpuart1, &fTempAtual, 2);
					}
					else if(ucParam == 'f'){
						//HAL_UART_Transmit_IT(&hlpuart1, &fDutyCycle, 3);
					}
				}
				ucUartState = IDDLE;
			}

			else if(ucUartState == VALUE){
				if((ucByte >= '0' && ucByte <= '9') || ucByte == '.' ){
					if(ucValueCount < NUM_MAX_VALUE){
						ucValue[ucValueCount++] = ucByte;
					}
				}
				else if(ucByte == ';'){
						float var_float = atof(ucValue);
						ucValue[ucValueCount] = '\0';
						if(ucParam == 't'){
							//dummy
						}
						else if(ucParam == 'q'){
							//dummy
						}
						else if(ucParam == 'b'){
							if(ucValue[0] == '0'){
								ledOFF(4);
								ledOFF(5);
							}
							else if(ucValue[0] == '1'){
								ledON(4);
								ledON(5);
							}
						}
						else if(ucParam == 'c'){
							//dummy
						}
						ucUartState = IDDLE;
					}

				}

		}
	}
}


