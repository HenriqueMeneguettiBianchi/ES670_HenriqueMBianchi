/* ***************************************************************** */
/* File name:        matrixKeyboard.c                                */
/* File description: Funções de matrixKeyboard.h                     */
/*                                                                   */
/* Author name:      Henrique M Bianchi                              */
/*                   Lucas Martins Cardozo                           */
/* Creation date:    10abr2023                                       */
/* Revision date:                                                    */
/* ***************************************************************** */
#include "matrixKeyboard.h"
#include "main.h"
#include "tim.h"

keyboardType xTeclado = {0};
keyboardTypeCont_500ms xContHalfS = {0};
keyboardTypeCont_3s xCont_3s = {0};
keyboardTypeFlag_3s xFlag_3s = {0};
static char cColuna =0;

TIM_HandleTypeDef *pTimerMatrixKeyboard;


void MatrixKeyboardInit(TIM_HandleTypeDef *htim){
	HAL_TIM_Base_Start_IT(&htim6);
}

keyboardType MatrixKeyboardGetKeys(){
	return xTeclado;
}

__weak void matrixKeyboardCallbackB_0HalfSec(){}
__weak void matrixKeyboardCallbackB_1HalfSec(){}
__weak void matrixKeyboardCallbackB_2HalfSec(){}
__weak void matrixKeyboardCallbackB_3HalfSec(){}
__weak void matrixKeyboardCallbackB_4HalfSec(){}
__weak void matrixKeyboardCallbackB_5HalfSec(){}
__weak void matrixKeyboardCallbackB_6HalfSec(){}
__weak void matrixKeyboardCallbackB_7HalfSec(){}
__weak void matrixKeyboardCallbackB_8HalfSec(){}
__weak void matrixKeyboardCallbackB_9HalfSec(){}
__weak void matrixKeyboardCallbackB_AHalfSec(){}
__weak void matrixKeyboardCallbackB_BHalfSec(){}
__weak void matrixKeyboardCallbackB_CHalfSec(){}
__weak void matrixKeyboardCallbackB_DHalfSec(){}
__weak void matrixKeyboardCallbackB_HHalfSec(){}
__weak void matrixKeyboardCallbackB_AsHalfSec(){}

__weak void matrixKeyboardCallbackB_0ThreeSec(){}
__weak void matrixKeyboardCallbackB_1ThreeSec(){}
__weak void matrixKeyboardCallbackB_2ThreeSec(){}
__weak void matrixKeyboardCallbackB_3ThreeSec(){}
__weak void matrixKeyboardCallbackB_4ThreeSec(){}
__weak void matrixKeyboardCallbackB_5ThreeSec(){}
__weak void matrixKeyboardCallbackB_6ThreeSec(){}
__weak void matrixKeyboardCallbackB_7ThreeSec(){}
__weak void matrixKeyboardCallbackB_8ThreeSec(){}
__weak void matrixKeyboardCallbackB_9ThreeSec(){}
__weak void matrixKeyboardCallbackB_AThreeSec(){}
__weak void matrixKeyboardCallbackB_BThreeSec(){}
__weak void matrixKeyboardCallbackB_CThreeSec(){}
__weak void matrixKeyboardCallbackB_DThreeSec(){}
__weak void matrixKeyboardCallbackB_HThreeSec(){}
__weak void matrixKeyboardCallbackB_AsThreeSec(){}


void timerMatrixKeyboardPeriodElapsedCallback(){

	if(cColuna >=4){
		cColuna = 0;
	}

	switch (cColuna){
		case 0:
			HAL_GPIO_WritePin(Teclado_Col1_GPIO_Port, Teclado_Col1_Pin, 1);
			HAL_GPIO_WritePin(Teclado_Col2_GPIO_Port, Teclado_Col2_Pin, 0);
			HAL_GPIO_WritePin(Teclado_Col3_GPIO_Port, Teclado_Col3_Pin, 0);
			HAL_GPIO_WritePin(Teclado_Col4_GPIO_Port, Teclado_Col4_Pin, 0);
//BOTÃ0 1
			if(HAL_GPIO_ReadPin(Teclado_Lin1_GPIO_Port, Teclado_Lin1_Pin) == 1){
				xTeclado.cB_1 = 1;
				xContHalfS.iB_1_500ms += 1;
				xCont_3s.iB_1_3s += 1;
				if(xCont_3s.iB_1_3s <= 75){
					if(xContHalfS.iB_1_500ms >= 12){
						xContHalfS.iB_1_500ms = 0;
						matrixKeyboardCallbackB_1HalfSec();
					}
				}
				else{
					xCont_3s.iB_1_3s = 0;
					if(xFlag_3s.cF_B_1 == 0){
						matrixKeyboardCallbackB_1ThreeSec();
					}
					xFlag_3s.cF_B_1 = 1;
				}
			}else{
				xTeclado.cB_1 = 0;
				xContHalfS.iB_1_500ms = 0;
				xCont_3s.iB_1_3s = 0;
				xFlag_3s.cF_B_1 = 0;
			}
//BOTÃO 4
			if(HAL_GPIO_ReadPin(Teclado_Lin2_GPIO_Port, Teclado_Lin2_Pin) == 1){
				xTeclado.cB_4 = 1;
				xContHalfS.iB_4_500ms += 1;
				xCont_3s.iB_4_3s += 1;
				if(xCont_3s.iB_4_3s <= 75){
					if(xContHalfS.iB_4_500ms >= 12){
						xContHalfS.iB_4_500ms = 0;
						matrixKeyboardCallbackB_4HalfSec();
					}
				}
				else{
					xCont_3s.iB_4_3s = 0;
					if(xFlag_3s.cF_B_4 == 0){
						matrixKeyboardCallbackB_4ThreeSec();
					}
					xFlag_3s.cF_B_4 = 1;
				}
			}else{
				xTeclado.cB_4 = 0;
				xContHalfS.iB_4_500ms = 0;
				xCont_3s.iB_4_3s = 0;
				xFlag_3s.cF_B_4 = 0;
			}
//BOTÃO 7
			if(HAL_GPIO_ReadPin(Teclado_Lin3_GPIO_Port, Teclado_Lin3_Pin) == 1){
				xTeclado.cB_7 = 1;
				xContHalfS.iB_7_500ms += 1;
				xCont_3s.iB_7_3s += 1;
				if(xCont_3s.iB_7_3s <= 75){
					if(xContHalfS.iB_7_500ms >= 12){
						xContHalfS.iB_7_500ms = 0;
						matrixKeyboardCallbackB_7HalfSec();
					}
				}
				else{
					xCont_3s.iB_7_3s = 0;
					if(xFlag_3s.cF_B_7 == 0){
						matrixKeyboardCallbackB_7ThreeSec();
					}
					xFlag_3s.cF_B_7 = 1;
				}
			}else{
				xTeclado.cB_7 = 0;
				xContHalfS.iB_7_500ms = 0;
				xCont_3s.iB_7_3s = 0;
				xFlag_3s.cF_B_7 = 0;
			}
//BOTÃO *
			if(HAL_GPIO_ReadPin(Teclado_Lin4_GPIO_Port, Teclado_Lin4_Pin) == 1){
				xTeclado.cB_As = 1;
				xContHalfS.iB_As_500ms += 1;
				xCont_3s.iB_As_3s += 1;
				if(xCont_3s.iB_As_3s <= 75){
					if(xContHalfS.iB_As_500ms >= 12){
						xContHalfS.iB_As_500ms = 0;
						matrixKeyboardCallbackB_AsHalfSec();
					}
				}
				else{
					xCont_3s.iB_As_3s = 0;
					if(xFlag_3s.cF_B_As == 0){
						matrixKeyboardCallbackB_AsThreeSec();
					}
					xFlag_3s.cF_B_As = 1;
				}
			}else{
				xTeclado.cB_As = 0;
				xContHalfS.iB_As_500ms = 0;
				xCont_3s.iB_As_3s = 0;
				xFlag_3s.cF_B_As = 0;
			}
			break;
		case 1:
			HAL_GPIO_WritePin(Teclado_Col1_GPIO_Port, Teclado_Col1_Pin, 0);
			HAL_GPIO_WritePin(Teclado_Col2_GPIO_Port, Teclado_Col2_Pin, 1);
			HAL_GPIO_WritePin(Teclado_Col3_GPIO_Port, Teclado_Col3_Pin, 0);
			HAL_GPIO_WritePin(Teclado_Col4_GPIO_Port, Teclado_Col4_Pin, 0);
//BOTÃO 2
			if(HAL_GPIO_ReadPin(Teclado_Lin1_GPIO_Port, Teclado_Lin1_Pin) == 1){
				xTeclado.cB_2 = 1;
				xContHalfS.iB_2_500ms += 1;
				xCont_3s.iB_2_3s += 1;
				if(xCont_3s.iB_2_3s <= 75){
					if(xContHalfS.iB_2_500ms >= 12){
						xContHalfS.iB_2_500ms = 0;
						matrixKeyboardCallbackB_2HalfSec();
					}
				}
				else{
					xCont_3s.iB_2_3s = 0;
					if(xFlag_3s.cF_B_2 == 0){
						matrixKeyboardCallbackB_2ThreeSec();
					}
					xFlag_3s.cF_B_2 = 1;
				}
			}else{
				xTeclado.cB_2 = 0;
				xContHalfS.iB_2_500ms = 0;
				xCont_3s.iB_2_3s = 0;
				xFlag_3s.cF_B_2 = 0;
			}
// BOTÃO 5
			if(HAL_GPIO_ReadPin(Teclado_Lin2_GPIO_Port, Teclado_Lin2_Pin) == 1){
				xTeclado.cB_5 = 1;
				xContHalfS.iB_5_500ms += 1;
				xCont_3s.iB_5_3s += 1;
				if(xCont_3s.iB_5_3s <= 75){
					if(xContHalfS.iB_5_500ms >= 12){
						xContHalfS.iB_5_500ms = 0;
						matrixKeyboardCallbackB_5HalfSec();
					}
				}
				else{
					xCont_3s.iB_5_3s = 0;
					if(xFlag_3s.cF_B_5 == 0){
						matrixKeyboardCallbackB_5ThreeSec();
					}
					xFlag_3s.cF_B_5 = 1;
				}
			}else{
				xTeclado.cB_5 = 0;
				xContHalfS.iB_5_500ms = 0;
				xCont_3s.iB_5_3s = 0;
				xFlag_3s.cF_B_5 = 0;
			}
//BOTÃO 8
			if(HAL_GPIO_ReadPin(Teclado_Lin3_GPIO_Port, Teclado_Lin3_Pin) == 1){
				xTeclado.cB_8 = 1;
				xContHalfS.iB_8_500ms += 1;
				xCont_3s.iB_8_3s += 1;
				if(xCont_3s.iB_8_3s <= 75){
					if(xContHalfS.iB_8_500ms >= 12){
						xContHalfS.iB_8_500ms = 0;
						matrixKeyboardCallbackB_8HalfSec();
					}
				}
				else{
					xCont_3s.iB_8_3s = 0;
					if(xFlag_3s.cF_B_8 == 0){
						matrixKeyboardCallbackB_8ThreeSec();
					}
					xFlag_3s.cF_B_8 = 1;
				}
			}else{
				xTeclado.cB_8 = 0;
				xContHalfS.iB_8_500ms = 0;
				xCont_3s.iB_8_3s = 0;
				xFlag_3s.cF_B_8 = 0;
			}
//BOTÃO 0
			if(HAL_GPIO_ReadPin(Teclado_Lin4_GPIO_Port, Teclado_Lin4_Pin) == 1){
				xTeclado.cB_0 = 1;
				xContHalfS.iB_0_500ms += 1;
				xCont_3s.iB_0_3s += 1;
				if(xCont_3s.iB_0_3s <= 75){
					if(xContHalfS.iB_0_500ms >= 12){
						xContHalfS.iB_0_500ms = 0;
						matrixKeyboardCallbackB_0HalfSec();
					}
				}
				else{
					xCont_3s.iB_0_3s = 0;
					if(xFlag_3s.cF_B_0 == 0){
						matrixKeyboardCallbackB_0ThreeSec();
					}
					xFlag_3s.cF_B_0 = 1;
				}
			}else{
				xTeclado.cB_0 = 0;
				xContHalfS.iB_0_500ms = 0;
				xCont_3s.iB_0_3s = 0;
				xFlag_3s.cF_B_0 = 0;
			}
			break;
		case 2:
			HAL_GPIO_WritePin(Teclado_Col1_GPIO_Port, Teclado_Col1_Pin, 0);
			HAL_GPIO_WritePin(Teclado_Col2_GPIO_Port, Teclado_Col2_Pin, 0);
			HAL_GPIO_WritePin(Teclado_Col3_GPIO_Port, Teclado_Col3_Pin, 1);
			HAL_GPIO_WritePin(Teclado_Col4_GPIO_Port, Teclado_Col4_Pin, 0);
//BOTÃO 3
			if(HAL_GPIO_ReadPin(Teclado_Lin1_GPIO_Port, Teclado_Lin1_Pin) == 1){
				xTeclado.cB_3 = 1;
				xContHalfS.iB_3_500ms += 1;
				xCont_3s.iB_3_3s += 1;
				if(xCont_3s.iB_3_3s <= 75){
					if(xContHalfS.iB_3_500ms >= 12){
						xContHalfS.iB_3_500ms = 0;
						matrixKeyboardCallbackB_3HalfSec();
					}
				}
				else{
					xCont_3s.iB_3_3s = 0;
					if(xFlag_3s.cF_B_3 == 0){
						matrixKeyboardCallbackB_3ThreeSec();
					}
					xFlag_3s.cF_B_3 = 1;
				}
			}else{
				xTeclado.cB_3 = 0;
				xContHalfS.iB_3_500ms = 0;
				xCont_3s.iB_3_3s = 0;
				xFlag_3s.cF_B_3 = 0;
			}
//BOTÃO 6
			if(HAL_GPIO_ReadPin(Teclado_Lin2_GPIO_Port, Teclado_Lin2_Pin) == 1){
				xTeclado.cB_6 = 1;
				xContHalfS.iB_6_500ms += 1;
				xCont_3s.iB_6_3s += 1;
				if(xCont_3s.iB_6_3s <= 75){
					if(xContHalfS.iB_6_500ms >= 12){
						xContHalfS.iB_6_500ms = 0;
						matrixKeyboardCallbackB_6HalfSec();
					}
				}
				else{
					xCont_3s.iB_6_3s = 0;
					if(xFlag_3s.cF_B_6 == 0){
						matrixKeyboardCallbackB_6ThreeSec();
					}
					xFlag_3s.cF_B_6 = 1;
				}
			}else{
				xTeclado.cB_6 = 0;
				xContHalfS.iB_6_500ms = 0;
				xCont_3s.iB_6_3s = 0;
				xFlag_3s.cF_B_6 = 0;
			}
//BOTÃO 9
			if(HAL_GPIO_ReadPin(Teclado_Lin3_GPIO_Port, Teclado_Lin3_Pin) == 1){
				xTeclado.cB_9 = 1;
				xContHalfS.iB_9_500ms += 1;
				xCont_3s.iB_9_3s += 1;
				if(xCont_3s.iB_9_3s <= 75){
					if(xContHalfS.iB_9_500ms >= 12){
						xContHalfS.iB_9_500ms = 0;
						matrixKeyboardCallbackB_9HalfSec();
					}
				}
				else{
					xCont_3s.iB_9_3s = 0;
					if(xFlag_3s.cF_B_9 == 0){
						matrixKeyboardCallbackB_9ThreeSec();
					}
					xFlag_3s.cF_B_9 = 1;
				}
			}else{
				xTeclado.cB_9 = 0;
				xContHalfS.iB_9_500ms = 0;
				xCont_3s.iB_9_3s = 0;
				xFlag_3s.cF_B_9 = 0;
			}
//BOTÃO #
			if(HAL_GPIO_ReadPin(Teclado_Lin4_GPIO_Port, Teclado_Lin4_Pin) == 1){
				xTeclado.cB_H = 1;
				xContHalfS.iB_H_500ms += 1;
				xCont_3s.iB_H_3s += 1;
				if(xCont_3s.iB_H_3s <= 75){
					if(xContHalfS.iB_H_500ms >= 12){
						xContHalfS.iB_H_500ms = 0;
						matrixKeyboardCallbackB_H_HalfSec();
					}
				}
				else{
					xCont_3s.iB_H_3s = 0;
					if(xFlag_3s.cF_B_H == 0){
						matrixKeyboardCallbackB_H_ThreeSec();
					}
					xFlag_3s.cF_B_H = 1;
				}
			}else{
				xTeclado.cB_H = 0;
				xContHalfS.iB_H_500ms = 0;
				xCont_3s.iB_H_3s = 0;
				xFlag_3s.cF_B_H = 0;
			}
			break;
		case 3:
			HAL_GPIO_WritePin(Teclado_Col1_GPIO_Port, Teclado_Col1_Pin, 0);
			HAL_GPIO_WritePin(Teclado_Col2_GPIO_Port, Teclado_Col2_Pin, 0);
			HAL_GPIO_WritePin(Teclado_Col3_GPIO_Port, Teclado_Col3_Pin, 0);
			HAL_GPIO_WritePin(Teclado_Col4_GPIO_Port, Teclado_Col4_Pin, 1);
//BOTÃO A
			if(HAL_GPIO_ReadPin(Teclado_Lin1_GPIO_Port, Teclado_Lin1_Pin) == 1){
				xTeclado.cB_A = 1;
				xContHalfS.iB_A_500ms += 1;
				xCont_3s.iB_A_3s += 1;
				if(xCont_3s.iB_A_3s <= 75){
					if(xContHalfS.iB_A_500ms >= 12){
						xContHalfS.iB_A_500ms = 0;
						matrixKeyboardCallbackB_A_HalfSec();
					}
				}
				else{
					xCont_3s.iB_A_3s = 0;
					if(xFlag_3s.cF_B_A == 0){
						matrixKeyboardCallbackB_A_ThreeSec();
					}
					xFlag_3s.cF_B_A = 1;
				}
			}else{
				xTeclado.cB_A = 0;
				xContHalfS.iB_A_500ms = 0;
				xCont_3s.iB_A_3s = 0;
				xFlag_3s.cF_B_A = 0;
			}
//BOTÃO B
			if(HAL_GPIO_ReadPin(Teclado_Lin2_GPIO_Port, Teclado_Lin2_Pin) == 1){
				xTeclado.cB_B = 1;
				xContHalfS.iB_B_500ms += 1;
				xCont_3s.iB_B_3s += 1;
				if(xCont_3s.iB_B_3s <= 75){
					if(xContHalfS.iB_B_500ms >= 12){
						xContHalfS.iB_B_500ms = 0;
						matrixKeyboardCallbackB_B_HalfSec();
					}
				}
				else{
					xCont_3s.iB_B_3s = 0;
					if(xFlag_3s.cF_B_B == 0){
						matrixKeyboardCallbackB_B_ThreeSec();
					}
					xFlag_3s.cF_B_B = 1;
				}
			}else{
				xTeclado.cB_B = 0;
				xContHalfS.iB_B_500ms = 0;
				xCont_3s.iB_B_3s = 0;
				xFlag_3s.cF_B_B = 0;
			}
// BOTÃO C
			if(HAL_GPIO_ReadPin(Teclado_Lin3_GPIO_Port, Teclado_Lin3_Pin) == 1){
				xTeclado.cB_C = 1;
				xContHalfS.iB_C_500ms += 1;
				xCont_3s.iB_C_3s += 1;
				if(xCont_3s.iB_C_3s <= 75){
					if(xContHalfS.iB_C_500ms >= 12){
						xContHalfS.iB_C_500ms = 0;
						matrixKeyboardCallbackB_C_HalfSec();
					}
				}
				else{
					xCont_3s.iB_C_3s = 0;
					if(xFlag_3s.cF_B_C == 0){
						matrixKeyboardCallbackB_C_ThreeSec();
					}
					xFlag_3s.cF_B_C = 1;
				}
			}else{
				xTeclado.cB_C = 0;
				xContHalfS.iB_C_500ms = 0;
				xCont_3s.iB_C_3s = 0;
				xFlag_3s.cF_B_C = 0;
			}
//BOTÃO D
			if(HAL_GPIO_ReadPin(Teclado_Lin4_GPIO_Port, Teclado_Lin4_Pin) == 1){
				xTeclado.cB_D = 1;
				xContHalfS.iB_D_500ms += 1;
				xCont_3s.iB_D_3s += 1;
				if(xCont_3s.iB_D_3s <= 75){
					if(xContHalfS.iB_D_500ms >= 12){
						xContHalfS.iB_D_500ms = 0;
						matrixKeyboardCallbackB_D_HalfSec();
					}
				}
				else{
					xCont_3s.iB_D_3s = 0;
					if(xFlag_3s.cF_B_D == 0){
						matrixKeyboardCallbackB_D_ThreeSec();
					}

					xFlag_3s.cF_B_D = 1;
				}
			}else{
				xTeclado.cB_D = 0;
				xContHalfS.iB_D_500ms = 0;
				xCont_3s.iB_D_3s = 0;
				xFlag_3s.cF_B_D = 0;
			}
			break;
	}
	cColuna++;
}

