
/* ********************************************************************** */
/* File name:        communicationStateMachine.h                          */
/* File description: Chamada das funções para communicationStateMachine.c */
/*                                                                        */
/* Author name:      Henrique M Bianchi                                   */
/*                   Lucas Martins Cardozo                                */
/* Creation date:    23mar2023                                            */
/* Revision date:                                                         */
/* ********************************************************************** */

#ifndef MAQUINA_ESTADO
#define MAQUINA_ESTADO
void initUart();
void maquinaEstadoByteCommunication(unsigned char ucByte);

#endif
