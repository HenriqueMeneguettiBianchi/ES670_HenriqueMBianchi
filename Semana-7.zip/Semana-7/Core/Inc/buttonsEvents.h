
/* ***************************************************************** */
/* File name:        buttonsEvents.h                                 */
/* File description: Chamada das funções para buttons.c              */
/*                                                                   */
/* Author name:      Henrique M Bianchi                              */
/*                   Lucas Martins Cardozo                           */
/* Creation date:    23mar2023                                       */
/* Revision date:                                                    */
/* ***************************************************************** */

#ifndef SOURCES_BUTTONS_EVENTS_H_
#define SOURCES_BUTTONS_EVENTS_H_

#include "tim.h"




void vButtonsEventCallbackPressedEvent(int ibutton_x);

void vButtonsEventCallbackReleasedEvent(int ibutton_x);

void vButtonsEventCallback500msPressedEvent(int ibutton_x);

void vButtonsEventCallback3sPressedEvent(int ibutton_x);

/* ************************************************ */
/* Method name: 	   vButtonsEventsInit         	*/
/* Method description: Inicializa funções dos bot   */
/* Input params:	   Timer Deboun e Timer Press   */
/* Output params:	   n/a 							*/
/* ************************************************ */
void vButtonsEventsInit(TIM_HandleTypeDef *pTimDebouncer,TIM_HandleTypeDef *pTimPressedTime);

void timerButtonsEventsDebouncingPeriodElapsedCallback();

void timerButtonsEventsLongPressPeriodElapsedCallback();

#endif

