
/* ***************************************************************** */
/* File name:        communication.h                                 */
/* File description: Chamada das funções para communication.c        */
/*                                                                   */
/* Author name:      Henrique M Bianchi                              */
/*                   Lucas Martins Cardozo                           */
/* Creation date:    23mar2023                                       */
/* Revision date:                                                    */
/* ***************************************************************** */

void initUart();

