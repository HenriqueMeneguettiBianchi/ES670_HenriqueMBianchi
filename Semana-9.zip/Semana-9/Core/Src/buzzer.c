/* ******************************************** */
/* File name:        buzzer.h                   */
/* File description: Corpo das funções de       */
/*                    manipulação e definição   */
/*                    do buzzer                 */
/* Author name:      Henrique Bianchi           */
/* Creation date:    15mai2023                  */
/* Revision date:                               */
/* ******************************************** */

#include "tim.h"
/* ************************************************ */
/* Method name: 	   vBuzzerPlay  	            */
/* Method description: Função para acionar o buzzer */
/* Input params:	   n/a                          */
/* Output params:	   n/a 				            */
/* ************************************************ */
void vBuzzerPlay(void){
	HAL_TIM_PWM_Start(&htim20, TIM_CHANNEL_1);
	TIM20->CCR1 = (htim20.Instance->ARR)/(float)2;
	HAL_TIM_Base_Start_IT(&htim5);
}

/* ************************************************ */
/* Method name: 	   vBuzzerConfig 	         	*/
/* Method description: Inicializa as configurações	*/
/* 					    para utilização do buzzer   */
/* Input params:	   usFrequency                  */
/* 					   usPeriod                     */
/* 					   htim                         */
/* Output params:	   n/a 							*/
/* ************************************************ */
void vBuzzerConfig(unsigned short int usFrequency, unsigned short int usPeriod, TIM_HandleTypeDef *htim){
	htim5.Instance->ARR = 10000*(usPeriod/1000.0f);
	htim20.Instance->ARR = 6071428*(1/(float)usFrequency);
	TIM20->CCR1 = (htim20.Instance->ARR)/(float)2; // metade do valor do duty cycle

}

void timerBuzzerPeriodElapsedCallback(){
	//Leva o duty cycle para 0
	TIM20->CCR1 = 0;
	HAL_TIM_Base_Stop_IT(&htim5);
}


