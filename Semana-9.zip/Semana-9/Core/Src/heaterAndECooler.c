/* ***************************************************************** */
/* File name:        heaterAndCooler.c                               */
/* File description: File dedicated to the hardware abstraction      */
/*                   layer related to the heater and cooler from     */
/*                   the hardware kit.                               */
/* Author name:      Henrique Bianchi                                */
/* Creation date:    11mai2023                                       */
/* Revision date:                                                    */
/* ***************************************************************** */

#include "heaterAndCooler.h"
#include "main.h"
#include "tim.h"

/* ************************************************ */
/* Method name: 	   vHeaterAndCoolerInit    		*/
/* Method description: Inicializa Cooler e Aquecedor*/
/* Input params:	   n/a 							*/
/* Output params:	   n/a 							*/
/* ************************************************ */
void vHeaterAndCoolerInit(){
	HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
}

/* ************************************************ */
/* Method name: 	   vCoolerfanPWMDuty       		*/
/* Method description: Define o DutyCicle do cooler */
/* Input params:	   fCoolerDuty                  */
/* Output params:	   n/a 							*/
/* ************************************************ */
void vCoolerfanPWMDuty(float fCoolerDuty){
	TIM8->CCR1 = (int)(1000*fCoolerDuty);
}

/* **************************************************** */
/* Method name: 	   vHeaterPWMDuty         		    */
/* Method description: Define o DutyCicle do aquecedor  */
/* Input params:	   fHeaterDuty                      */
/* Output params:	   n/a 							    */
/* **************************************************** */
void vHeaterPWMDuty(float fHeaterDuty){
	TIM1->CCR1 = (int)(1000*fHeaterDuty);
}
