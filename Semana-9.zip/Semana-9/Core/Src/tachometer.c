/* ***************************************************************** */
/* File name:        tachometer.c	                                 */
/* File description: Contem as funcoes que trabalham com o           */
/* 					 tacômetro e suas manipulacoes					 */
/* 					                                                 */
/* Author name:      Henrique Meneguetti Bianchi                     */
/* Creation date:    17mai2023                                       */
/* Revision date:                                                    */
/* ***************************************************************** */
#include "tim.h"
#include "main.h"
#include "tachometer.h"

unsigned short int usCoolerSpeed = 0;
TIM_HandleTypeDef *pTimerTachometer;
unsigned int uiAuxPeriod;

/* ************************************************ */
/* Method name: 	   vTachometerInit 	         	*/
/* Method description: Initialize the tachometer	*/
/* 					   functions 		            */
/* Input params:	   htim                         */
/* 					   uiPeriod                     */
/* Output params:	   n/a 							*/
/* ************************************************ */
void vTachometerInit(TIM_HandleTypeDef *htim, unsigned int uiPeriod){
	//start do módulo TIM utilizado para definir a janela de tempo
	uiAuxPeriod = uiPeriod;
	pTimerTachometer = htim;
	HAL_TIM_Base_Start_IT(pTimerTachometer);

	//Clock de 100000 * periodo em segundo
	htim4.Instance->ARR = 100000*(uiAuxPeriod/1000.0f);
	HAL_TIM_Base_Start_IT(&htim4);
}

/* ************************************************ */
/* Method name: 	   TachometerUpdate         	*/
/* Method description: Update the tachometer    	*/
/* Input params:	   n/a                          */
/* Output params:	   n/a 							*/
/* ************************************************ */
void TachometerUpdate(void){
	//A cada interrupção (cada vez que passar pela janela do TIM4)
	//	deve-se contar, quantas vezes teve um bloqueio do sinal pela aleta do cooler.
	usCoolerSpeed = htim3.Instance->CNT;

	// uiPeriod esta em milisegundos
	usCoolerSpeed = (((float)usCoolerSpeed)*60*1000)/(9*(float)uiAuxPeriod);

	//Zera o contador para próxima contagem
	htim3.Instance->CNT = 0;
}

void timerTachometerPeriodElapsedCallback(){
	TachometerUpdate();
}
