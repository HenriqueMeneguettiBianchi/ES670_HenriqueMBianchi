/* ***************************************************************** */
/* File name:        buttonsEvents.c                                 */
/* File description: Funções de buttonsEvents.c                      */
/*                                                                   */
/* Author name:      Henrique M Bianchi                              */
/*                   Lucas Martins Cardozo                           */
/* Creation date:    15abr2023                                       */
/* Revision date:                                                    */
/* ***************************************************************** */
#include "buttonsEvents.h"
#include "buttons.h"
#include "main.h"
#include "tim.h"

TIM_HandleTypeDef *pTimerButtonsEventsDebouncing, *pTimerButtonsEventsLongPress;


char cFlagButton;

char cFlag_3s_Bt_Cima = 0;
char cFlag_3s_Bt_Baixo = 0;
char cFlag_3s_Bt_Esquerdo = 0;
char cFlag_3s_Bt_Direito = 0;
char cFlag_3s_Bt_Enter = 0;


int iCont_Bt_Cima_500ms = 0;
int iCont_Bt_Baixo_500ms = 0;
int iCont_Bt_Esquerdo_500ms = 0;
int iCont_Bt_Direito_500ms = 0;
int iCont_Bt_Enter_500ms = 0;

int iCont_Bt_Cima_3s = 0;
int iCont_Bt_Baixo_3s = 0;
int iCont_Bt_Esquerdo_3s = 0;
int iCont_Bt_Direito_3s = 0;
int iCont_Bt_Enter_3s = 0;

__weak void vButtonsEventCallbackPressedEvent(int ibutton_x){}

__weak void vButtonsEventCallbackReleasedEvent(int ibutton_x){}

__weak void vButtonsEventCallback500msPressedEvent(int ibutton_x){}

__weak void vButtonsEventCallback3sPressedEvent(int ibutton_x){}

/* ************************************************ */
/* Method name: 	   vButtonsEventsInit         	*/
/* Method description: Inicializa funções dos bot   */
/* Input params:	   Timer Deboun e Timer Press   */
/* Output params:	   n/a 							*/
/* ************************************************ */
void vButtonsEventsInit(TIM_HandleTypeDef *pTimDebouncer,TIM_HandleTypeDef *pTimPressedTime){
	pTimerButtonsEventsDebouncing = pTimDebouncer;
	pTimerButtonsEventsLongPress = pTimPressedTime;
}


void HAL_GPIO_EXTI_Callback (uint16_t GPIO_Pin){
	if(GPIO_Pin == Bt_Cima_Pin){
		//desabilita
		HAL_NVIC_DisableIRQ(EXTI1_IRQn);
		//inicializa o timer htim 7
		HAL_TIM_Base_Start_IT(pTimerButtonsEventsDebouncing);
		//conta o timer de debouncing 1x
		//vai para timerButtonsEventsDebouncingPeriodElapsedCallback();
		cFlagButton = 1;
	}
	if(GPIO_Pin == Bt_Baixo_Pin){
		//desabilita
		HAL_NVIC_DisableIRQ(EXTI2_IRQn);
		//inicializa o timer htim 7
		HAL_TIM_Base_Start_IT(pTimerButtonsEventsDebouncing);
		//conta o timer de debouncing 1x
		//vai para timerButtonsEventsDebouncingPeriodElapsedCallback();
		cFlagButton = 2;
	}
	if(GPIO_Pin == Bt_Esquerdo_Pin){
		//desabilita
		HAL_NVIC_DisableIRQ(EXTI3_IRQn);
		//inicializa o timer htim 7
		HAL_TIM_Base_Start_IT(pTimerButtonsEventsDebouncing);
		//conta o timer de debouncing 1x
		//vai para timerButtonsEventsDebouncingPeriodElapsedCallback();
		cFlagButton = 3;
	}
	if(GPIO_Pin == Bt_Direito_Pin){
		//desabilita
		HAL_NVIC_DisableIRQ(EXTI4_IRQn);
		//inicializa o timer htim 7
		HAL_TIM_Base_Start_IT(pTimerButtonsEventsDebouncing);
		//conta o timer de debouncing 1x
		//vai para timerButtonsEventsDebouncingPeriodElapsedCallback();
		cFlagButton = 4;
	}
	if(GPIO_Pin == Bt_Enter_Pin){
		//Desabilita a interrupção do botão
		HAL_NVIC_DisableIRQ(EXTI0_IRQn);
		//inicializa o timer htim 7
		HAL_TIM_Base_Start_IT(pTimerButtonsEventsDebouncing);
		//conta o timer de debouncing 1x
		//vai para timerButtonsEventsDebouncingPeriodElapsedCallback();
		cFlagButton = 5;
		}
}



/* ******************************************************************************** */
/* Method name: 	   timerButtonsEventsDebouncingPeriodElapsedCallback         	*/
/* Method description:    */
/* Input params:	                                                                */
/* Output params:	   n/a 						                                 	*/
/* ******************************************************************************** */
void timerButtonsEventsDebouncingPeriodElapsedCallback(){

	if(cFlagButton == 1){
		//Reativa a Interrupção
		HAL_NVIC_EnableIRQ(EXTI1_IRQn);
		//Para o timer para contar apenas 1x
		HAL_TIM_Base_Stop_IT(pTimerButtonsEventsDebouncing);
		//Zera o contador do timer
		TIM7->CNT = 0;
		if(HAL_GPIO_ReadPin(Bt_Cima_GPIO_Port, Bt_Cima_Pin) == 1){
			vButtonsEventCallbackPressedEvent(1);
			HAL_TIM_Base_Start_IT(pTimerButtonsEventsLongPress);
		}
		else{
			vButtonsEventCallbackReleasedEvent(1);
			iCont_Bt_Cima_500ms = 0;
			iCont_Bt_Cima_3s = 0;
			cFlag_3s_Bt_Cima = 0;
		}
	}
	if(cFlagButton == 2){
		//Reativa a Interrupção
		HAL_NVIC_EnableIRQ(EXTI2_IRQn);
		//Para o timer para contar apenas 1x
		HAL_TIM_Base_Stop_IT(pTimerButtonsEventsDebouncing);
		//Zera o contador do timer
		TIM7->CNT = 0;
		if(HAL_GPIO_ReadPin(Bt_Baixo_GPIO_Port, Bt_Baixo_Pin) == 1){
			vButtonsEventCallbackPressedEvent(2);
			HAL_TIM_Base_Start_IT(pTimerButtonsEventsLongPress);
		}
		else{
			vButtonsEventCallbackReleasedEvent(2);
			iCont_Bt_Baixo_500ms = 0;
			iCont_Bt_Baixo_3s = 0;
			cFlag_3s_Bt_Baixo = 0;
		}
	}
	if(cFlagButton == 3){
		//Reativa a Interrupção
		HAL_NVIC_EnableIRQ(EXTI3_IRQn);
		//Para o timer para contar apenas 1x
		HAL_TIM_Base_Stop_IT(pTimerButtonsEventsDebouncing);
		//Zera o contador do timer
		TIM7->CNT = 0;
		if(HAL_GPIO_ReadPin(Bt_Esquerdo_GPIO_Port, Bt_Esquerdo_Pin) == 1){
			vButtonsEventCallbackPressedEvent(3);
			HAL_TIM_Base_Start_IT(pTimerButtonsEventsLongPress);
		}
		else{
			vButtonsEventCallbackReleasedEvent(3);
			iCont_Bt_Baixo_500ms = 0;
			iCont_Bt_Baixo_3s = 0;
			cFlag_3s_Bt_Baixo = 0;
		}
	}
	if(cFlagButton == 4){
		//Reativa a Interrupção
		HAL_NVIC_EnableIRQ(EXTI4_IRQn);
		//Para o timer para contar apenas 1x
		HAL_TIM_Base_Stop_IT(pTimerButtonsEventsDebouncing);
		//Zera o contador do timer
		TIM7->CNT = 0;
		if(HAL_GPIO_ReadPin(Bt_Direito_GPIO_Port, Bt_Direito_Pin) == 1){
			vButtonsEventCallbackPressedEvent(4);
			HAL_TIM_Base_Start_IT(pTimerButtonsEventsLongPress);
		}
		else{
			vButtonsEventCallbackReleasedEvent(4);
			iCont_Bt_Baixo_500ms = 0;
			iCont_Bt_Baixo_3s = 0;
			cFlag_3s_Bt_Baixo = 0;
		}
	}

	if(cFlagButton == 5){
		//Reativa a Interrupção
		HAL_NVIC_EnableIRQ(EXTI0_IRQn);
		//Para o timer para contar apenas 1x
		HAL_TIM_Base_Stop_IT(pTimerButtonsEventsDebouncing);
		//Zera o contador do timer
		TIM7->CNT = 0;
		if(HAL_GPIO_ReadPin(Bt_Enter_GPIO_Port, Bt_Enter_Pin) == 1){
			vButtonsEventCallbackPressedEvent(5);
			HAL_TIM_Base_Start_IT(pTimerButtonsEventsLongPress);
		}
		else{
			vButtonsEventCallbackReleasedEvent(2);
			iCont_Bt_Enter_500ms = 0;
			iCont_Bt_Enter_3s = 0;
			cFlag_3s_Bt_Enter = 0;
		}
	}
}
/* ******************************************************************************** */
/* Method name: 	   timerButtonsEventsLongPressPeriodElapsedCallback         	*/
/* Method description:    */
/* Input params:	                                                                */
/* Output params:	   n/a 						                                 	*/
/* ******************************************************************************** */
void timerButtonsEventsLongPressPeriodElapsedCallback(){
	if(HAL_GPIO_ReadPin(Bt_Cima_GPIO_Port, Bt_Cima_Pin) == 1){
		iCont_Bt_Cima_500ms++;
		iCont_Bt_Cima_3s++;
		if(iCont_Bt_Cima_3s <= 300){
			if(iCont_Bt_Cima_500ms >= 50){
				iCont_Bt_Cima_500ms = 0;
				vButtonsEventCallback500msPressedEvent(1);
			}
			else{
				iCont_Bt_Cima_3s = 0;
				if(cFlag_3s_Bt_Cima == 0){
					vButtonsEventCallback3sPressedEvent(1);
				}
				cFlag_3s_Bt_Cima = 1;
			}
		}
	}
	else{
		iCont_Bt_Cima_500ms = 0;
		iCont_Bt_Cima_3s = 0;
		cFlag_3s_Bt_Cima = 0;
	}

	if(HAL_GPIO_ReadPin(Bt_Baixo_GPIO_Port, Bt_Baixo_Pin) == 1){
		iCont_Bt_Baixo_500ms++;
		iCont_Bt_Baixo_3s++;
		if(iCont_Bt_Baixo_3s <= 300){
			if(iCont_Bt_Baixo_500ms >= 50){
				iCont_Bt_Baixo_500ms = 0;
				vButtonsEventCallback500msPressedEvent(2);
			}
			else{
				iCont_Bt_Baixo_3s = 0;
				if(cFlag_3s_Bt_Baixo == 0){
					vButtonsEventCallback3sPressedEvent(2);
				}
				cFlag_3s_Bt_Baixo = 1;
			}
		}
	}
	else{
		iCont_Bt_Baixo_500ms = 0;
		iCont_Bt_Baixo_3s = 0;
		cFlag_3s_Bt_Baixo = 0;
	}

	if(HAL_GPIO_ReadPin(Bt_Esquerdo_GPIO_Port, Bt_Esquerdo_Pin) == 1){
			iCont_Bt_Esquerdo_500ms++;
			iCont_Bt_Esquerdo_3s++;
			if(iCont_Bt_Esquerdo_3s <= 300){
				if(iCont_Bt_Esquerdo_500ms >= 50){
					iCont_Bt_Esquerdo_500ms = 0;
					vButtonsEventCallback500msPressedEvent(3);
				}
				else{
					iCont_Bt_Esquerdo_3s = 0;
					if(cFlag_3s_Bt_Esquerdo == 0){
						vButtonsEventCallback3sPressedEvent(3);
					}
					cFlag_3s_Bt_Esquerdo = 1;
				}
			}
		}
		else{
			iCont_Bt_Esquerdo_500ms = 0;
			iCont_Bt_Esquerdo_3s = 0;
			cFlag_3s_Bt_Esquerdo = 0;
		}

	if(HAL_GPIO_ReadPin(Bt_Direito_GPIO_Port, Bt_Direito_Pin) == 1){
			iCont_Bt_Direito_500ms++;
			iCont_Bt_Direito_3s++;
			if(iCont_Bt_Direito_3s <= 300){
				if(iCont_Bt_Direito_500ms >= 50){
					iCont_Bt_Direito_500ms = 0;
					vButtonsEventCallback500msPressedEvent(4);
				}
				else{
					iCont_Bt_Direito_3s = 0;
					if(cFlag_3s_Bt_Direito == 0){
						vButtonsEventCallback3sPressedEvent(4);
					}
					cFlag_3s_Bt_Direito = 1;
				}
			}
		}
		else{
			iCont_Bt_Direito_500ms = 0;
			iCont_Bt_Direito_3s = 0;
			cFlag_3s_Bt_Direito = 0;
		}

	if(HAL_GPIO_ReadPin(Bt_Enter_GPIO_Port, Bt_Enter_Pin) == 1){
		iCont_Bt_Enter_500ms++;
		iCont_Bt_Enter_3s++;
		if(iCont_Bt_Enter_3s <= 300){
			if(iCont_Bt_Enter_500ms >= 50){
				iCont_Bt_Enter_500ms = 0;
				vButtonsEventCallback500msPressedEvent(5);
			}
		}
		else{
			iCont_Bt_Enter_3s = 0;
			if(cFlag_3s_Bt_Enter == 0){
				vButtonsEventCallback3sPressedEvent(5);
			}
			cFlag_3s_Bt_Enter = 1;
		}
	}
	else{
		iCont_Bt_Enter_500ms = 0;
		iCont_Bt_Enter_3s = 0;
		cFlag_3s_Bt_Enter = 0;
	}

}
