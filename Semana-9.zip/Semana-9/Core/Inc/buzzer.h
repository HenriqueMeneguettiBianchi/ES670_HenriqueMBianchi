/* ******************************************** */
/* File name:        buzzer.h                   */
/* File description: Hearder das funções de     */
/*                    manipulação e definição   */
/*                    do buzzer                 */
/* Author name:      Henrique Bianchi           */
/* Creation date:    15mai2023                  */
/* Revision date:                               */
/* ******************************************** */


/* ************************************************ */
/* Method name: 	   vBuzzerPlay  	         	*/
/* Method description: Função para acionar o buzzer	*/
/* Input params:	   n/a                          */
/* Output params:	   n/a 							*/
/* ************************************************ */
void vBuzzerPlay(void);


/* ************************************************ */
/* Method name: 	   vBuzzerConfig 	         	*/
/* Method description: Inicializa as configurações	*/
/* 					    para utilização do buzzer   */
/* Input params:	   usFrequency                  */
/* 					   usPeriod                     */
/* 					   htim                         */
/* Output params:	   n/a 							*/
/* ************************************************ */
void vBuzzerConfig(unsigned short int usFrequency, unsigned short int usPeriod, TIM_HandleTypeDef *htim);


