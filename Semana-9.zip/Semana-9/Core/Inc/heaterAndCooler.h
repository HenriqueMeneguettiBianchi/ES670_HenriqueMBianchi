/* ***************************************************************** */
/* File name:        heaterAndCooler.h                               */
/* File description: File dedicated to the hardware abstraction      */
/*                   layer related to the heater and cooler from     */
/*                   the hardware kit.                               */
/* Author name:      Henrique Bianchi                                */
/* Creation date:    11mai2023                                       */
/* Revision date:                                                    */
/* ***************************************************************** */

#ifndef SOURCES_HEATERANDCOOLER_H
#define SOURCES_HEATERANDCOOLER_H

/* ************************************************ */
/* Method name: 	   vHeaterAndCoolerInit    		*/
/* Method description: Inicializa Cooler e Aquecedor*/
/* Input params:	   n/a 							*/
/* Output params:	   n/a 							*/
/* ************************************************ */
void vHeaterAndCoolerInit();

/* ************************************************ */
/* Method name: 	   vCoolerfanPWMDuty       		*/
/* Method description: Define o DutyCicle do cooler */
/* Input params:	   fCoolerDuty                  */
/* Output params:	   n/a 							*/
/* ************************************************ */
void vCoolerfanPWMDuty(float fCoolerDuty);

/* **************************************************** */
/* Method name: 	   vHeaterPWMDuty         		    */
/* Method description: Define o DutyCicle do aquecedor  */
/* Input params:	   fHeaterDuty                      */
/* Output params:	   n/a 							    */
/* **************************************************** */
void vHeaterPWMDuty(float fHeaterDuty);

#endif
