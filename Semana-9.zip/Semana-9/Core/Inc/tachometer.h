/* ***************************************************************** */
/* File name:        tachometer.h                              		 */
/* File description: Header file containing the prototypes of the    */
/*                   functions used to configure and set tachometer  */
/*                                               					 */
/* Author name:      Henrique Meneguetti Bianchi                     */
/* Creation date:    17mai2023                                       */
/* Revision date:                                                    */
/* ***************************************************************** */

/* ************************************************ */
/* Method name: 	   vTachometerInit 	         	*/
/* Method description: Initialize the tachometer	*/
/* 					   functions 		            */
/* Input params:	   htim                         */
/* 					   uiPeriod                     */
/* Output params:	   n/a 							*/
/* ************************************************ */
void vTachometerInit(TIM_HandleTypeDef *htim, unsigned int uiPeriod);

/* ************************************************ */
/* Method name: 	   vTachometerInit 	         	*/
/* Method description: Initialize the tachometer	*/
/* 					   functions 		            */
/* Input params:	   TIM_HandleTypeDef *htim      */
/* 					   unsigned int uiPeriod        */
/* Output params:	   n/a 							*/
/* ************************************************ */
void TachometerUpdate(void);

void timerTachometerPeriodElapsedCallback();
