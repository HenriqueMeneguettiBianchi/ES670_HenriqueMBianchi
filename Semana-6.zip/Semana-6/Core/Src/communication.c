/* ***************************************************************** */
/* File name:        communication.c                                 */
/* File description: Funções de communication.c                      */
/*                                                                   */
/* Author name:      Henrique M Bianchi                              */
/*                   Lucas Martins Cardozo                           */
/* Creation date:    15abr2023                                       */
/* Revision date:                                                    */
/* ***************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "led.h"
#include "usart.h"

 unsigned char c;

 void initUart(){
		HAL_UART_Receive_IT(&hlpuart1, &c, 1);
 }

void HAL_UART_RxCpltCallback (UART_HandleTypeDef *huart){
	if(huart == &hlpuart1){
		HAL_UART_Transmit_IT(&hlpuart1, &c, 1);
		HAL_UART_Receive_IT(&hlpuart1, &c, 1);
	}
}

