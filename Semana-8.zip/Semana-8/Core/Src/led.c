/* ***************************************************************** */
/* File name:        led.c                                	         */
/* File description: Corpo das funções em led.h                      */
/*                                                                   */
/* Author name:      Henrique M Bianchi                              */
/*                   Lucas Martins Cardozo                           */
/* Creation date:    23mar2023                                       */
/* Revision date:                                                    */
/* ***************************************************************** */
#include "main.h"
#include "led.h"

/* ************************************************ */
/* Method name: 	   ledInitLed           		*/
/* Method description: Inicializa funções dos leds  */
/* Input params:	   n/a                          */
/* Output params:	   n/a 							*/
/* ************************************************ */
void ledInitLed(){

	//Libera Clock para Porta A e B
	RCC->AHB2ENR |= 0x3;

	//Define a Porta PA5 como GPIO
	GPIOA->MODER &= ~0x800;
	GPIOA->MODER |= 0x400;
	//Define PA5 como GPIO_Push-Pull (LED Verde 1)
	GPIOA->OTYPER &= ~0x20;

	//Define a Porta PA4 como GPIO
	GPIOA->MODER &= ~0x200;
	GPIOA->MODER |= 0x100;
	//Define PA4 como GPIO_Push-Pull (LED Amarelo)
	GPIOA->OTYPER &= ~0x10;

	//Define a Porta PB14 como GPIO
	GPIOB->MODER &= ~0x20000000;
	GPIOB->MODER |= 0x10000000;
	//Define PB14 como GPIO_Push-Pull (LED Vermelho)
	GPIOB->OTYPER &= ~0x4000;

	//Define a Porta PA12 como GPIO
	GPIOA->MODER &= ~0x2000000;
	GPIOA->MODER |= 0x100000;
	//Define PA12 como GPIO_Push-Pull (LED Verde 2)
	GPIOA->OTYPER &= ~0x1000;

	//Define a Porta PB5 como GPIO
	GPIOB->MODER &= ~0x800;
	GPIOB->MODER |= 0x400;
	//Define PB5 como GPIO_Push-Pull (LED Azul)
	GPIOB->OTYPER &= ~0x20;
}

/* ************************************************ */
/* Method name: 	   ledWrite	         		    */
/* Method description: Escreve valor alto ou baixo  */
/*                     no led                       */
/* Input params:	   Inteiro Led (1 a 5)          */
/*                     1 = led acesso               */
/*                     0 = led apagado              */
/* Output params:	   n/a 							*/
/* ************************************************ */
void ledWrite(int iled_x, int i_estado){
  //LED Verde 1
  if(iled_x == 1){
    if(i_estado==0){
    	GPIOA->ODR &= ~0x20;
    }
    else if (i_estado==1){
    	GPIOA->ODR |= 0x20;
    }
  }
  //LED Amarelo
  else if (iled_x == 2){
    if(i_estado==0){
    	GPIOA->ODR &= ~0x10;
    }
    else if (i_estado==1){
    	GPIOA->ODR |= 0x10;
    }
  }
  //LED Vermelho
    else if (iled_x == 3){
      if(i_estado==0){
      	GPIOB->ODR &= ~0x4000;
      }
      else if (i_estado==1){
      	GPIOB->ODR |= 0x4000;
      }
    }
  //LED Verde 2
  else if (iled_x == 4){
    if(i_estado==0){
    	GPIOA->ODR &= ~0x1000;
    }
    else if (i_estado==1){
    	GPIOA->ODR |= 0x1000;
    }
  }
  //LED Azul
  else if (iled_x == 5){
    if(i_estado==0){
    	GPIOB->ODR &= ~0x20;
    }
    else if (i_estado==1){
    	GPIOB->ODR |= 0x20;
    }
  }
}

/* ************************************************ */
/* Method name: 	   ledON                 		*/
/* Method description: Acende LED indicado          */
/* Input params:	   Inteiro Led (1 a 5)          */
/* Output params:	   n/a 							*/
/* ************************************************ */
void ledON(int iled_x){
  //LED Verde 1
  if(iled_x==1){
	GPIOA->ODR |= 0x20;
	}
  //LED Amarelo
  else if(iled_x==2){
	GPIOA->ODR |= 0x10;
  }
  //LED Vermelho
  else if(iled_x==3){
	GPIOB->ODR |= 0x4000;
    }
  //LED Verde 2
  else if(iled_x==4){
	GPIOA->ODR |= 0x1000;
  }
  //LED Azul
  else if(iled_x==5){
	GPIOB->ODR |= 0x20;
  }
}

/* ************************************************ */
/* Method name: 	   ledOFF               		*/
/* Method description: Apaga LED indicado           */
/* Input params:	   Inteiro Led (1 a 5)          */
/* Output params:	   n/a 							*/
/* ************************************************ */
void ledOFF(int iled_x){

  //LED Verde 1
  if(iled_x==1){
	GPIOA->ODR &= ~0x20;
  }
  //LED Amarelo
  else if(iled_x==2){
	GPIOA->ODR &= ~0x10;
  }
  //LED Vermelho
  else if(iled_x==3){
	GPIOB->ODR &= ~0x4000;
  }
  //LED Verde 2
  else if(iled_x==4){
	GPIOA->ODR &= ~0x1000;
  }
  //LED Azul
  else if(iled_x==5){
	GPIOB->ODR &= ~0x20;
  }
}

/* ************************************************ */
/* Method name: 	   led_Toggle              		*/
/* Method description: Altera estado LED do indicado*/
/* Input params:	   Inteiro Led (1 a 5)          */
/* Output params:	   n/a 							*/
/* ************************************************ */
void ledToggle(int iled_x){
  int aux=0;

  if(iled_x==1){
	  aux = (GPIOA->ODR & 0x20);
	  aux = aux>>5;
	  if(aux==0){
		  ledON(1);
	  }
	  else if(aux==1){
		  ledOFF(1);
	  }
  }

  else if(iled_x==2){
	  aux = (GPIOA->ODR & 0x10);
	  aux = aux>>4;
	  if(aux==0){
		  ledON(2);
	  }
	  else if(aux==1){
		  ledOFF(2);
	  }
  }

  else if(iled_x==3){
	  aux = (GPIOB->ODR & 0x4000);
	  aux = aux>>14;
	  if(aux==0){
		  ledON(3);
	  }
	  else if(aux==1){
		  ledOFF(3);
	  }
  }

  else if(iled_x==4){
	  aux = (GPIOA->ODR & 0x1000);
	  aux = aux>>12;
	  if(aux==0){
		  ledON(4);
	  }
	  else if(aux==1){
		  ledOFF(4);
	  }
  }

  else if(iled_x==5){
	  aux = (GPIOB->ODR & 0x20);
	  aux = aux>>5;
	  if(aux==0){
		  ledON(5);
	  }
	  else if(aux==1){
		  ledOFF(5);
	  }
  }
}
