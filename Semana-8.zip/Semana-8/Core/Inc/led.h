/* ***************************************************************** */
/* File name:        led.h                                           */
/* File description: Chamada das funções para led.C                  */
/*                                                                   */
/* Author name:      Henrique M Bianchi                              */
/*                   Guilherme S Brumatti                            */
/* Creation date:    23mar2023                                       */
/* Revision date:                                                    */
/* ***************************************************************** */

#ifndef SOURCES_LED_H_
#define SOURCES_LED_H_


/* ************************************************ */
/* Method name: 	   ledInitLed           		*/
/* Method description: Inicializa funções dos leds  */
/* Input params:	   Led   (1 a 5)                */
/* Output params:	   n/a 							*/
/* ************************************************ */
void ledInitLed();


/* ************************************************ */
/* Method name: 	   ledWrite	         		    */
/* Method description: Escreve valor alto ou baixo  */
/*                     no led                       */
/* Input params:	   Inteiro Led (1 a 5)          */
/*                     1 = led acesso               */
/*                     0 = led apagado              */
/* Output params:	   n/a 							*/
/* ************************************************ */
void ledWrite(int iled_x, int i_estado);


/* ************************************************ */
/* Method name: 	   led_ON               		*/
/* Method description: Acende LED indicado          */
/* Input params:	   Inteiro Led (1 a 5)          */
/* Output params:	   n/a 							*/
/* ************************************************ */
void ledON(int iled_x);


/* ************************************************ */
/* Method name: 	   led_OFF               		*/
/* Method description: Apaga LED indicado           */
/* Input params:	   Inteiro Led (1 a 5)          */
/* Output params:	   n/a 							*/
/* ************************************************ */
void ledOFF(int iled_x);


/* ************************************************ */
/* Method name: 	   led_Toggle              		*/
/* Method description: Altera estado LED do indicado*/
/* Input params:	   Inteiro Led (1 a 5)          */
/* Output params:	   n/a 							*/
/* ************************************************ */
void ledToggle(int iled_x);

#endif


