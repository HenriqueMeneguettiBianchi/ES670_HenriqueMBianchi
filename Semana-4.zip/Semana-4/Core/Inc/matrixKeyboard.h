/* ***************************************************************** */
/* File name:        matrixKeyboard.h                                */
/* File description: Corpo das funções para matrixKeyboard.c         */
/*                                                                   */
/* Author name:      Henrique M Bianchi                              */
/*                   Guilherme S Brumatti                            */
/* Creation date:    10abr2023                                       */
/* Revision date:                                                    */
/* ***************************************************************** */

#ifndef INC_MATRIXKEYBOARD_H_
#define INC_MATRIXKEYBOARD_H_
#include "stm32g4xx_hal.h"

typedef struct{
	char cB_0;
	char cB_1;
	char cB_2;
	char cB_3;
	char cB_4;
	char cB_5;
	char cB_6;
	char cB_7;
	char cB_8;
	char cB_9;
	char cB_A;
	char cB_B;
	char cB_C;
	char cB_D;
	char cB_H;
	char cB_As;
} keyboardType;

typedef struct{
	int iB_0_500ms;
	int iB_1_500ms;
	int iB_2_500ms;
	int iB_3_500ms;
	int iB_4_500ms;
	int iB_5_500ms;
	int iB_6_500ms;
	int iB_7_500ms;
	int iB_8_500ms;
	int iB_9_500ms;
	int iB_A_500ms;
	int iB_B_500ms;
	int iB_C_500ms;
	int iB_D_500ms;
	int iB_H_500ms;
	int iB_As_500ms;
} keyboardTypeCont_500ms;

typedef struct{
	int iB_0_3s;
	int iB_1_3s;
	int iB_2_3s;
	int iB_3_3s;
	int iB_4_3s;
	int iB_5_3s;
	int iB_6_3s;
	int iB_7_3s;
	int iB_8_3s;
	int iB_9_3s;
	int iB_A_3s;
	int iB_B_3s;
	int iB_C_3s;
	int iB_D_3s;
	int iB_H_3s;
	int iB_As_3s;
} keyboardTypeCont_3s;

typedef struct{
	char cF_B_0;
	char cF_B_1;
	char cF_B_2;
	char cF_B_3;
	char cF_B_4;
	char cF_B_5;
	char cF_B_6;
	char cF_B_7;
	char cF_B_8;
	char cF_B_9;
	char cF_B_A;
	char cF_B_B;
	char cF_B_C;
	char cF_B_D;
	char cF_B_H;
	char cF_B_As;
}keyboardTypeFlag_3s;

__weak void matrixKeyboardCallbackB_0HalfSec();
__weak void matrixKeyboardCallbackB_1HalfSec();
__weak void matrixKeyboardCallbackB_2HalfSec();
__weak void matrixKeyboardCallbackB_3HalfSec();
__weak void matrixKeyboardCallbackB_4HalfSec();
__weak void matrixKeyboardCallbackB_5HalfSec();
__weak void matrixKeyboardCallbackB_6HalfSec();
__weak void matrixKeyboardCallbackB_7HalfSec();
__weak void matrixKeyboardCallbackB_8HalfSec();
__weak void matrixKeyboardCallbackB_9HalfSec();
__weak void matrixKeyboardCallbackB_A_HalfSec();
__weak void matrixKeyboardCallbackB_B_HalfSec();
__weak void matrixKeyboardCallbackB_C_HalfSec();
__weak void matrixKeyboardCallbackB_D_HalfSec();
__weak void matrixKeyboardCallbackB_H_HalfSec();
__weak void matrixKeyboardCallbackB_AsHalfSec();

__weak void matrixKeyboardCallbackB_0ThreeSec();
__weak void matrixKeyboardCallbackB_1ThreeSec();
__weak void matrixKeyboardCallbackB_2ThreeSec();
__weak void matrixKeyboardCallbackB_3ThreeSec();
__weak void matrixKeyboardCallbackB_4ThreeSec();
__weak void matrixKeyboardCallbackB_5ThreeSec();
__weak void matrixKeyboardCallbackB_6ThreeSec();
__weak void matrixKeyboardCallbackB_7ThreeSec();
__weak void matrixKeyboardCallbackB_8ThreeSec();
__weak void matrixKeyboardCallbackB_9ThreeSec();
__weak void matrixKeyboardCallbackB_A_ThreeSec();
__weak void matrixKeyboardCallbackB_B_ThreeSec();
__weak void matrixKeyboardCallbackB_C_ThreeSec();
__weak void matrixKeyboardCallbackB_D_ThreeSec();
__weak void matrixKeyboardCallbackB_H_ThreeSec();
__weak void matrixKeyboardCallbackB_AsThreeSec();

void MatrixKeyboardInit(TIM_HandleTypeDef *htim);

keyboardType MatrixKeyboardGetKeys();

void HAL_TIM_PeriodElapsedCallback (TIM_HandleTypeDef * htim);


#endif /* INC_MATRIXKEYBOARD_H_ */
