/* ***************************************************************** */
/* File name:        buttons.h                                       */
/* File description: Chamada das funções para buttons.c              */
/*                                                                   */
/* Author name:      Henrique M Bianchi                              */
/*                   Guilherme S Brumatti                            */
/* Creation date:    23mar2023                                       */
/* Revision date:                                                    */
/* ***************************************************************** */

#ifndef SOURCES_BUTTONS_H_
#define SOURCES_BUTTONS_H_


/* ************************************************ */
/* Method name: 	   ledInitLed           		*/
/* Method description: Inicializa funções dos leds  */
/* Input params:	   Led   (1 a 5)                */
/* Output params:	   n/a 							*/
/* ************************************************ */
void buttonsInitButtons();


/* ************************************************ */
/* Method name: 	   statusButton        	*/
/* Method description: Mostra o status do botão     */
/* Input params:	   Inteiro (1 a 5)              */
/* Output params:	   1 = botão pressionado 		*/
/*					   0 = botão solto              */
/* ************************************************ */
int statusButton(int ibutton_x);

#endif
